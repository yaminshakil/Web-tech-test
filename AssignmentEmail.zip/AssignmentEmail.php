<?php


	


if(isset($_GET['submit'])){
	echo $_GET['FirstName'];
		
	}

?>




<!DOCTYPE html>
<html>
<head>
	<title>Sign in Ymail</title>
</head>

<body>


<a  href="SecondPage.php">
	         			
	         			<button>TRY</button>
	         			</a>





<h1 align="center">Fill all the imformation to create YMAIL</h1>


<table align="center">
	<form method="get" action="">

		<tr>
		<td>

		
      
			
		    <b>First Name :  </b><input type="text" name="FirstName">
			<b>Last Name :  </b><input type="text" name="LastName">
	        </br></br>

	         <b>Enter your Username :  </b><input type="text"  colspan="1" name="Username" value=""/>

	         </br></br>

	         <b>Enter Password    :  </b><input type="password" name="Password" value=""/>

	         </br></br>

	         <b>Re- Password      :  </b><input type="password" name="Password2" value=""/>


             </br></br>

	         <b>Date of Birth     :  </b><input type="date" name="DOB" value=""/>



             </br></br>

	         <b>Gender     :</b>
	         					<input type="radio" name="gender" value=""/>Male
	         					<input type="radio" name="gender" value=""/>Female
	         					<input type="radio" name="gender" value=""/>Other



	         					</br></br>

	         <b>Phone Number :  </b><input type="text"  colspan="1" name="Phone" value=""/>

 							</br></br>
 							<a  href="SecondPage.php">
	         			  <input type="submit"  name="submit" value="Submit"/>
	         			</a>

         </td>
      

		</tr>

		</table>

       
			 

			 










	</form>

</body>

</html>